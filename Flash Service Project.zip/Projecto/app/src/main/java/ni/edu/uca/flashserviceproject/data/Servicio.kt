package ni.edu.uca.flashserviceproject.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable
import java.text.SimpleDateFormat

@Entity(tableName = "Servicios")
class Servicio (
    val nombre:String,
    val monto: Double,
    val mes: String,
    val fecha: String,
    @PrimaryKey(autoGenerate = true)
    var idServicio: Int = 0

    ) : Serializable