package ni.edu.uca.flashserviceproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import ni.edu.uca.flashserviceproject.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val sesion = findViewById<Button>(R.id.btn_iniciarSesion)


        sesion.setOnClickListener {
            val intento2 = Intent (this, IniciarSesion::class.java)
            startActivity(intento2)
        }


        binding.btnIniciarSesion.setOnClickListener {
            startActivity(Intent(this, IniciarSesion()::class.java))
        }

        binding.registroBtn.setOnClickListener {
            startActivity(Intent(this,RegistroCuenta()::class.java))
        }



    }


}