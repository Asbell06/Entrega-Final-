package ni.edu.uca.flashserviceproject

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_cuenta.*
import ni.edu.uca.flashserviceproject.data.DatabaseHelper

class Cuenta : AppCompatActivity() {

    lateinit var handler: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cuenta)

        handler = DatabaseHelper(this)

        val atras = findViewById<Button>(R.id.btn_atras)
        val guardar = findViewById<Button>(R.id.btn_cuenta_guardar)

        handler.getUserData(et_cuenta_nombre.text.toString(), ete_correo.text.toString(), etp_contraseña.text.toString(),etp_fondos.text.toString())


        guardar.setOnClickListener {
            val txtNombre : TextView = findViewById(R.id.et_cuenta_nombre)
            val txtCorreo : TextView = findViewById(R.id.et_correo)
            val txtContra : TextView = findViewById(R.id.et_contraseña)
            val txtFondos : TextView = findViewById(R.id.etp_fondos)


        }

        atras.setOnClickListener {
            val intento1 = Intent (this, ServicioMenu::class.java)
            startActivity(intento1)
        }
    }
}