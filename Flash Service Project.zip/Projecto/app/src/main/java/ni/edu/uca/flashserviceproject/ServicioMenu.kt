package ni.edu.uca.flashserviceproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ServicioMenu : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_servicio_menu)

        val cuenta = findViewById<Button>(R.id.cuenta)
        val registrarGastos = findViewById<Button>(R.id.gastos)
        val mensual = findViewById<Button>(R.id.mensual)

        cuenta.setOnClickListener {
            val intento1 = Intent (this, Cuenta()::class.java)
            startActivity(intento1)
        }

        registrarGastos.setOnClickListener {
            val intento2 = Intent (this, Add()::class.java)
            startActivity(intento2)
        }

        mensual.setOnClickListener {
            val intento3 = Intent (this, GastoMensual()::class.java)
            startActivity(intento3)
        }

    }
}