package ni.edu.uca.flashserviceproject

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import kotlinx.android.synthetic.main.activity_servicio.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import ni.edu.uca.flashserviceproject.data.AppDatabase
import ni.edu.uca.flashserviceproject.data.Servicio

class ServicioActivity : AppCompatActivity() {

    private lateinit var database: AppDatabase
    private lateinit var servicio: Servicio
    private lateinit var servicioLiveData: LiveData<Servicio>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_servicio)

        val hecho = findViewById<Button>(R.id.btn_hecho)

        hecho.setOnClickListener {
            val intento2 = Intent (this, Add::class.java)
            startActivity(intento2)
        }

        database = AppDatabase.getDatabase(this)

        val idServicio = intent.getIntExtra("id", 0)

        servicioLiveData = database.servicios().get(idServicio)

        servicioLiveData.observe(this, Observer {
            servicio = it

            tv_nombre.text = servicio.nombre
            tv_monto.text = "$${servicio.monto}"
            tv_mes.text = servicio.mes
            tv_fecha.text = servicio.fecha
        })


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.servicio_menu, menu)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            R.id.edit_item ->{
                val intent = Intent (this, NuevoServicio::class.java)
                intent.putExtra("servicio", servicio)
                startActivity(intent)
            }
            R.id.delete_item ->{
                servicioLiveData.removeObservers(this)
                CoroutineScope(Dispatchers.IO).launch {
                    database.servicios().delete(servicio)
                    this@ServicioActivity.finish()
                }

            }
        }

        return super.onOptionsItemSelected(item)
    }



}