package ni.edu.uca.flashserviceproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_registro_cuenta.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import ni.edu.uca.flashserviceproject.data.DatabaseHelper

class RegistroCuenta : AppCompatActivity() {

    lateinit var handler: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_cuenta)

        handler = DatabaseHelper(this)

        val guardar = findViewById<Button>(R.id.btn_guardar)

        guardar.setOnClickListener {
            handler.insertUserData(et_usuario.text.toString(), et_correo.text.toString(), et_password.text.toString(), et_fd.text.toString())

            Toast.makeText(this, "Usuario registrado exitosamente", Toast.LENGTH_LONG).show()

                this@RegistroCuenta.finish()

        }

    }
}